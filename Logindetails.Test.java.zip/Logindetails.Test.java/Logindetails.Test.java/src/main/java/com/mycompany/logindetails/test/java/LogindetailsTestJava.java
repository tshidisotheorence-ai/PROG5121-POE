/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.logindetails.test.java;

/**
 *
 * @author tshid
 */
   import org.junit.jupiter.api.Test;
   import static org.junit.jupiter.api.Assertions.*;

    class LoginTest

    Login login = new Login();

    // 🔹 Test Username Validation
    @Test
    void testValidUsername() {
        assertTrue(login.checkUsername("ab_cd"));
    }

    @Test
    void testInvalidUsername_NoUnderscore() {
        assertFalse(login.checkUsername("abcd"));
    }

    @Test
    void testInvalidUsername_TooLong() {
        assertFalse(login.checkUsername("abc_def"));
    }

    // 🔹 Test Password Complexity
    @Test
    void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Pass@123"));
    }

    @Test
    void testPassword_NoCapital() {
        assertFalse(login.checkPasswordComplexity("pass@123"));
    }

    @Test
    void testPassword_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Pass@word"));
    }

    @Test
    void testPassword_NoSpecialChar() {
        assertFalse(login.checkPasswordComplexity("Pass1234"));
    }

    @Test
    void testPassword_TooShort() {
        assertFalse(login.checkPasswordComplexity("P@1a"));
    }

    // 🔹 Test Cell Phone Number
    @Test
    void testValidCellNumber() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    void testInvalidCellNumber_NoCountryCode() {
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    void testInvalidCellNumber_TooShort() {
        assertFalse(login.checkCellPhoneNumber("+27831"));
    }

    // 🔹 Test Login Functionality
    @Test
    void testSuccessfulLogin() {
        login.registerUser("ab_cd", "Pass@123", "John", "Doe");
        assertTrue(login.loginUser("ab_cd", "Pass@123"));
    }

    @Test
    void testFailedLogin_WrongPassword() {
        login.registerUser("ab_cd", "Pass@123", "John", "Doe");
        assertFalse(login.loginUser("ab_cd", "Wrong@123"));
    }
}

     
    

